<?php
$con = mysql_connect('localhost','root');

if($con){
	echo "Connection successful";
}else{
	echo "No connection";
}
mysql_select_db($con,'foodexpressuserdata')
$user = $_POST['user'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$comments = $_POST['comments'];
$query = "insert into userinfodata (user,email, mobile,comments)"
values('$user','$email','$mobile','$comments')

mysql_query($con,$query);

?>